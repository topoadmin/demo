;(function() {
	'use stric'
	const doc = window.document
	const $ = (el, method = false) => {
		if (method) {
			return doc.querySelectorAll(el)
		} else {
			return doc.querySelector(el)
		}
	}
	
	class Game {
		constructor(arg) {
			this.opt = Object.assign({
				el: 'body',
				chessboard: 5
			}, arg)
			
			this.__recordSteps = []
			this.el = $(this.opt.el)
		}
		paint () { // 绘制棋盘
			this.__paintInit = true
			const chessboard = Array.from({ length: this.opt.chessboard }).map((row, index) => {
				index = index + 1
				const rowEl = doc.createElement('div')
				rowEl.className = 'game-row'
				this.el.appendChild(rowEl)
				
				return Array.from({ length: index }).map((child, cindex) => {
					const colEl = doc.createElement('div')
					colEl.className = 'game-col'
					rowEl.appendChild(colEl)
					
					const chess = doc.createElement('div')
					const id = `game-chess-${index}-${cindex+1}`
					chess.id = id
					chess.className = 'game-chess'
					colEl.appendChild(chess)
					const obj = {
						position: [index, cindex+1],
						id,
						status: false // 是否为空
					}
					chess.addEventListener('click', () => {
						this.step(obj, chess)
					})
					return obj
				})
			})
			this.chessboard = chessboard
		}
		step (chess, el) { // 开始跳子，选中的子朝着空位跳，中间必须隔着一个存在的子
			if (this.__paintInit) { // 第一步随便点
				el.classList.add('game-chess__close')
				this.__paintInit = false
				chess.status = true
				this.recordStep(chess)
				return false
			}
			const clearFoucs = () => { // 清理选中的棋子
				this.el.querySelectorAll('.game-chess').forEach(gc => {
					gc.classList.remove('game-chess__foucs')
				})
				el.classList.add('game-chess__foucs')
				this.__chessA = chess.position
			}
			// 第二步开始需要点击两次
			if (this.__chessA) {
				if (chess.status) { // 落点不能是有棋子的位置
					this.__chessZ = chess.position
					this.toStep()
				} else {
					clearFoucs()
				}
			} else {
				clearFoucs()
			}
		}
		toStep () { // 目标位置符合放置规则
			console.log(`开始位【${this.__chessA}】,  结束位置【${this.__chessZ}】`)
		}
		recordStep (chess) { // 记录步骤
			this.__recordSteps.push(chess.position)
		}
		time () { // 计时器
			console.log('paint')
		}
		alert (msg) { // 提示信息
			if (this.$alertEl) {
				this.$alertEl.remove()
				this.$alertEl = null
				clearTimeout(this.$alertTime)
				this.$alertTime = null
			}
			const el = doc.createElement('div')
			el.className = 'game-alert'
			el.innerText = msg
			doc.body.appendChild(el)
			this.$alertEl = el
			this.$alertTime = setTimeout(() => {
				if (this.$alertEl) {
					this.$alertEl.remove()
					this.$alertEl = null
				}
				this.$alertTime = null
			}, 2000)
		}
	}
	
	doc.addEventListener('DOMContentLoaded', () => {
		const game = new Game({ el: '#game' })
		game.paint()
	})
}());